import React from 'react';
import Feed from './Feed';

function App() {
  return (
    <div className="App">
      <h1>Social Media Feed</h1>
      <Feed />
    </div>
  );
}

export default App;
